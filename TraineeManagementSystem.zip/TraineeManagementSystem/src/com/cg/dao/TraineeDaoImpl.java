package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.dto.Login;

import com.cg.dto.Trainee;
@Repository("dao")
@Transactional
public class TraineeDaoImpl implements TraineeDao
{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public boolean isUserExist(String unm) {
		
		Login login=entityManager.find(Login.class, unm);
		if(login!=null)
		{
			return true;
		}
		else
		{
		return false;
		}
	}

	

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	@Override
	public boolean isValid(Login log) {
	

		Login lg=entityManager.find(Login.class, log.getUsername());
		if(log.getPassword().equalsIgnoreCase(lg.getPassword()))
		{
			return true;
		}
		else
		{
		return false;
		}
	
	}



	@Override
	public Trainee addTrainee(Trainee tr1) {
		
		
		entityManager.persist(tr1);
		
		return tr1;
	}



	@Override
	public Trainee deleteTrainee(int id) {
	
	Trainee tr2=entityManager.find(Trainee.class,id);
		
		entityManager.remove(tr2);
		
		return tr2;
	}



	@Override
	public Trainee searchTrainee(int id) {
		
		Trainee tr2=entityManager.find(Trainee.class,id);
		
		return tr2;
	}



	@Override
	public ArrayList<Trainee> getAllUsers() {
		
		String qry="select trainee from Trainee trainee";
		TypedQuery<Trainee> tq=entityManager.createQuery(qry,Trainee.class);
		ArrayList<Trainee> userL=(ArrayList)tq.getResultList();
		
		return userL;
	}



	@Override
	public Trainee modifyDetails(Trainee trr) {
		
		Trainee tr7=entityManager.find(Trainee.class, trr.getTraineeId());
		tr7.setTraineeId(trr.getTraineeId());
		tr7.setTraineeName(trr.getTraineeName());
		tr7.setTraineeLocation(trr.getTraineeLocation());
		tr7.setTraineeDomain(trr.getTraineeDomain());
		//Trainee tr4=entityManager.merge(tr7);
		
		return tr7;
	}

}
