package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Login;

import com.cg.dto.Trainee;

public interface TraineeDao
{
	public boolean isUserExist(String unm);
	public boolean isValid(Login log);
	public Trainee addTrainee(Trainee tr1 );
	public Trainee deleteTrainee(int id);
	public Trainee searchTrainee(int id);
	public ArrayList<Trainee> getAllUsers();
	public Trainee modifyDetails(Trainee trr);
}
